
collect.scores <- data.frame()

predict.uni <- function(test.df, filename){
  print("Validation scores of Cox model in test or validation data")
  # Validation *****************************
  for (i in predictors){
    scores=as.data.frame(predict(univ_models[[i]], 
                                 newdata=test.df, 
                                 se.type="expected")) # the expected number of events given the covariates and follow-up time
    scores = scores %>%
      set_colnames(c("Score")) %>%
      rownames_to_column(var = "SampleID")
    
    collect.scores<- rbind(collect.scores, scores)
    univ_models[[i]]$scores <- collect.scores
    
    # Validation *****************************
    # Read the real labels that were hidden from that algorithm
    labels <- test.df
    labels$SampleID<- rownames(test.df)
    
    # Align the user provided scores with the true event times
    true.scores <- as.numeric(labels[scores$SampleID,"Event_time"])
    
    # Calculate Harrell's C statistics
    HarrellC <- Hmisc::rcorr.cens(scores$Score, true.scores, outx=FALSE)
    
    print(HarrellC["C Index"])
    univ_models[[i]]$HarrellC <- HarrellC["C Index"]
  
  }
  return(univ_models)
}

# Validation of univariate cox model in TEST and VALIDATION cohorts ************
predict.uni(df.test, "ontest")
predict.uni(df.val, "onvalidation")


# collect harrelc
collect.harrelc <- data.frame()
for (i in predictors){
  hC=univ_models[[i]]$HarrellC
  collect.harrelc=rbind(collect.harrelc, hC)
}
rownames(collect.harrelc) <- predictors
write.csv(collect.harrelc, file=paste0(PARAM$folder.result, 
                                Sys.Date(), "_",
                                "HarrellC_univariate.csv"))
# multivar *****************************

print("Cox survival multivariate model building")
cox.multivar <- coxph(Surv(Event_time, Event)~., data=data)


predict.multi <- function(model.fit, test.df, filename){
  print("Validation scores of Cox model in test or validation data")
  # Validation *****************************
  scores=as.data.frame(predict(model.fit, 
                               newdata=test.df, 
                               se.type="expected")) # the expected number of events given the covariates and follow-up time
  scores = scores %>%
    set_colnames(c("Score")) %>%
    rownames_to_column(var = "SampleID")
  
  # export file
  write.csv(scores, file=paste0(PARAM$folder.result, 
                                Sys.Date(), "_",
                                filename, "_",
                                "predictions.csv"))
  
  # Validation *****************************
  print("HarrellC index of Cox model in test data")
  # Read the real labels that were hidden from that algorithm
  labels <- test.df
  labels$SampleID<- rownames(test.df)
  
  # Align the user provided scores with the true event times
  true.scores <- as.numeric(labels[scores$SampleID,"Event_time"])
  
  # Calculate Harrell's C statistics
  HarrellC <- Hmisc::rcorr.cens(scores$Score, true.scores, outx=FALSE)
  
  print("HarrellC index")
  print(HarrellC["C Index"])
  
  write.csv(HarrellC, file=paste0(PARAM$folder.result, 
                                  Sys.Date(), "_",
                                  filename, "_",
                                  "HarrellC.csv"))
}

# Validation of multivariate cox model in TEST and VALIDATION cohorts **********
predict.multi(cox.multivar, df.test, "cox_multivar_ontest_")
predict.multi(cox.multivar, df.val, "cox_multivar_onvalidation_")






###############################################################################
# Multivariate Cox regression analysis
###############################################################################
print("Cox survival multivariate model building")
cox.multivar <- coxph(Surv(Event_time, Event)~., data=data)

###############################################################################
# Validation of cox models in TEST and VALIDATION cohorts
###############################################################################

predict.F <- function(model.fit, test.df, filename){
  print("Validation scores of Cox model in test or validation data")
  # Validation *****************************
  scores=as.data.frame(predict(model.fit, 
                               newdata=test.df, 
                               se.type="expected")) # the expected number of events given the covariates and follow-up time
  scores = scores %>%
    set_colnames(c("Score")) %>%
    rownames_to_column(var = "SampleID")
  
  # export file
  write.csv(scores, file=paste0(PARAM$folder.result, 
                                Sys.Date(), "_",
                                filename, "_",
                                "predictions.csv"))
  
  # Validation *****************************
  print("HarrellC index of Cox model in test data")
  # Read the real labels that were hidden from that algorithm
  labels <- test.df
  labels$SampleID<- rownames(test.df)
  
  # Align the user provided scores with the true event times
  true.scores <- as.numeric(labels[scores$SampleID,"Event_time"])
  
  # Calculate Harrell's C statistics
  HarrellC <- Hmisc::rcorr.cens(scores$Score, true.scores, outx=FALSE)
  
  print("HarrellC index")
  print(HarrellC["C Index"])
  
  write.csv(HarrellC, file=paste0(PARAM$folder.result, 
                                  Sys.Date(), "_",
                                  filename, "_",
                                  "HarrellC.csv"))
}
# Validation of univariate cox model in TEST and VALIDATION cohorts ************
predict.F(cox.mod.total.meta, df.test, "cox_totalmeta_ontest_")
predict.F(cox.mod.total.meta, df.val, "cox_totalmeta_onvalidation_")

# Validation of multivariate cox model in TEST and VALIDATION cohorts **********
predict.F(cox.multivar, df.test, "cox_multivar_ontest_")
predict.F(cox.multivar, df.val, "cox_multivar_onvalidation_")

