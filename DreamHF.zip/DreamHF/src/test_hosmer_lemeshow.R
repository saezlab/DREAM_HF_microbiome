rm(list=ls())
setwd("/csc/fr_metagenome/pheno")
library(survival)
options(width=200) # characters per line
source("Hosmer.test_etc.R")

load('2015_60_Salomaa_Jain_dataFR02_FU17_2020-11-15.RData') # FR02 is the data set loaded
FR02$NON_HDL <- FR02$KOL-FR02$HDL
vars <- c("INCIDENT_HFAIL","HFAIL_AGEDIFF","BL_AGE","MEN","CURR_SMOKE",
          "BP_TREAT","PREVAL_DIAB","PREVAL_CHD","SYSTM","NON_HDL")

dat <- subset(data,select=predictors,PrevalentHFAIL==0&!is.na(Event))


res <- coxph(Surv(Event_time, Event)~.,data=dat)

pred <- Coxar(res,years=16)
test <- HosLem.test(res$y,pred,plot=FALSE)
test$pval
# [1] 0.6608073